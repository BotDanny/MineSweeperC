/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include "game_core.h"

bool step(const int c, const int r, const int width) {
    if (c > width - 1 || r > width - 1 || c < 0 || r < 0) {
        return false;
    }
    if (mine_at(c,r)) {
        board[r * width + c] = MINE;
        return true;
    } else if (board[r * width + c] >= 0 && board[r * width + c] <= 8) {
    } else {
        int mines = 0;
        for (int tempc = c - 1; tempc <= c + 1; tempc++) {
            for (int tempr = r - 1; tempr <= r + 1; tempr++) {
                if (mine_at(tempc,tempr)) {
                    mines++;
                }
            }
        }
        board[r * width + c] = mines;
    }
    return false;
}

bool step_adv(const int c, const int r, const int width) {
    if (c > width - 1 || r > width - 1 || c < 0 || r < 0) {
        return false;
    }
    int mines = 0;
    if (mine_at(c,r)) {
        board[r * width + c] = MINE;
        return true;
    } else if (board[r * width + c] >= 0 && board[r * width + c] <= 8) {
        return false;
    } else {
        for (int tempc = c - 1; tempc <= c + 1; tempc++) {
            for (int tempr = r - 1; tempr <= r + 1; tempr++) {
                if (mine_at(tempc,tempr)) {
                    mines++;
                }
            }
        }
        board[r * width + c] = mines;
    }
    if (mines == 0) {
        for (int tempc = c - 1; tempc <= c + 1; tempc++) {
            for (int tempr = r - 1; tempr <= r + 1; tempr++) {
                step_adv(tempc,tempr,width);
            }
        }
    }
    return false;
}


bool mark(const int c, const int r, int width) {
    if (board[r * width + c] >= 0 && board[r * width + c] <= 8) {
    } else if (board[r * width + c] == MARKED) {
        board[r * width + c] = UNKNOWN;
    } else {
        board[r * width + c] = MARKED;
    }
    if (all_marked()) {
        return true;
    }
    return false;
}

void print(int width) {
    printf ("\n");
    for (int j = 0; j < width; j++) {
        printf ("---");
    }
    printf ("\n");
    printf ("    ");
    for (int i = 0; i < width; i++) {
        if (i > 9) {
            printf ("%d",i);
        } else {
            printf ("%d ",i);
        }
    }
    printf ("\n");
    for (int i = 0; i < width; i++) {
        printf("---");
    }
     printf ("\n");
    for (int r = 0; r < width; r++) {
        if (r > 9) {
            printf ("%d| ",r);
        } else {
            printf ("%d | ",r);
        }
        for (int c = 0; c < width; c++) {
            if (board[r * width + c] == UNKNOWN) {
                printf ("_");
            } else if (board[r * width + c] == MARKED) {
                printf ("M");
            } else if (board[r * width + c] == MINE) {
                printf ("*");
            } else {
                printf ("%d", board[r * width + c]);
            }
            if (c != width - 1) {
                printf (" ");
            }
        }
        printf ("\n");
    }
    printf ("\n");
    for (int j = 0; j < width; j++) {
        printf ("---");
    }
    printf ("\n");
}

void print_clear(int width) {
    printf ("\n");
    for (int j = 0; j < width; j++) {
        printf ("---");
    }
    printf ("\n");
    printf ("    ");
    for (int i = 0; i < width; i++) {
        if (i > 9) {
            printf ("%d",i);
        } else {
            printf ("%d ",i);
        }
    }
    printf ("\n");
    for (int i = 0; i < width; i++) {
        printf("---");
    }
     printf ("\n");
    for (int r = 0; r < width; r++) {
        if (r > 9) {
            printf ("%d| ",r);
        } else {
            printf ("%d | ",r);
        }
        for (int c = 0; c < width; c++) {
            if (map[r * width + c] == UNKNOWN) {
                printf ("_");
            } else if (map[r * width + c] == MARKED) {
                printf ("M");
            } else if (map[r * width + c] == MINE) {
                printf ("*");
            } else {
                printf ("%d", map[r * width + c]);
            }
            if (c != width - 1) {
                printf (" ");
            }
        }
        printf ("\n");
    }
    printf ("\n");
    for (int j = 0; j < width; j++) {
        printf ("---");
    }
    printf ("\n");
}

void user_guide(void) {
    printf("Command avaliable: S for stepping (on a position),A for Advanced stepping (on a position)\n");
    printf("Command avaliable: M for marking (a position),Q for quitting and U for printing user guide\n");
    printf("Position: First the column, then a space, then the row\n");
    printf("Example: S 2 2 steps on the position 2,2 on the board \n");
}