/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   game.h
 * Author: admin
 *
 * Created on May 18, 2019, 6:32 PM
 */

#ifndef GAME_H
#define GAME_H

#include <stdbool.h>
#include "game_core.h"

/*
 * step(c, r, width, heigth) reveales the content of a square with the
 *   coordinates ([c]olumn,[r]ow). The function returns false if the square does
 *   not contain a mine or if ([c],[r]) has been stepped on before.
 * effects: sets map at ([c],[r]) accordingly.
 */
bool step(const int c, const int r, const int width);

/*
 * step_adv(c, r, width, heigth) reveales the content of a square with
 *   the coordinates ([c]olumn,[r]ow). If the revealed square is not next to a
 *   mine, it reveales also all adjacent fields. The function returns false if
 *   the square does not contain a mine or if ([c],[r]) has been stepped on
 *   before.
 * effects: sets map at ([c],[r]) accordingly.
 */
bool step_adv(const int c, const int r, const int width);

/*
 * mark(c, r, width, heigth) marks or unmarks the square with coordinates
 *   ([c]olumn,[r]ow), i.e., it signals weather this square contains a mine or
 *   not. The function returns true if all mines on the board have been marked,
 *   or false otherwise.
 * effects: sets map at ([c],[r]) accordingly.
 */
bool mark(const int c, const int r, const int width);

/*
 * print(width, height) prints the current map to the console. Unexplored
 *   squares are represented by '_ ', marked squares by 'P ', and mines by 'X '.
 * effects: writes to the console
 */
void print(const int width);

void print_clear(const int width);

void user_guide(void);

#endif /* GAME_H */

