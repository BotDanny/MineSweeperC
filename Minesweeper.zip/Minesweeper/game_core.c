/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int UNKNOWN = -1;

int MINE = -2;

int MARKED = -3;

int width;

int *map;

int *board;

bool unique(const int *inputlist, const int index, const int num) {
    for (int i =0; i < index; i++) {
        if (inputlist[i] == num) return false;
    }
    return true;
}

int *uniquepos(const int mapsize, const int minecount) {
    srand(time(0));
    int *mine_position = malloc(300 * (sizeof(int)));
    
    for (int i = 0; i < minecount; i++) {
        int randnum = (rand() % mapsize);
        mine_position[i] = randnum;
        while (!unique(mine_position,i,randnum)) {
            randnum = (rand() % mapsize);
            mine_position[i] = randnum;
        }
    }
    return mine_position;
}

int init_d(const char size, const char hardness) {
    
    int mapsize;
    int minecount;
    
    if (size == 's' || size == 'S' ) {
        mapsize = 100;
        width = 10;
    } else if (size == 'm' || size == 'M') {
        mapsize = 225;
        width = 15;
    } else {
        width = 20;
        mapsize = 400;
    }
    map = malloc(mapsize * sizeof(int));
    board = malloc(mapsize * sizeof(int));
    
    
    if (hardness == 'e' || hardness == 'E') {
        minecount = (int)(mapsize * 0.1);
    } else if (hardness == 'm' || hardness == 'M') {
        minecount =(int)(mapsize * 0.2);
    } else {
        minecount = (int)(mapsize * 0.3);
    }
    
    for (int j = 0; j < mapsize; j++) {
        map[j] = 0;
        board[j] = UNKNOWN;
    }
    
    int *unique_position = uniquepos(mapsize, minecount);
    
    
    for (int i = 0; i < minecount; i++) {
        map[unique_position[i]] = MINE;
    }
    free(unique_position);
    return (int)(sqrt(mapsize));
}

bool mine_at(const int c, const int r) {
    if (c > width - 1 || r > width - 1 || c < 0 || r < 0) {
        return false;
    }
    return map[r * width + c] == MINE;
}
bool all_marked(void) {
    for (int i = 0; i < pow(width, 2); i++) {
        if (map[i] == MINE) {
            if (board[i] != MARKED) return false;
        }
    }
    return true;
}

void shutdown() {
    free(board);
    free(map);
}

