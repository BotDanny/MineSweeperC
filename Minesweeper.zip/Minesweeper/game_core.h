/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   game_core.h
 * Author: admin
 *
 * Created on May 18, 2019, 3:33 PM
 */

#ifndef GAME_CORE_H
#define GAME_CORE_H

#include <stdbool.h>

/*
 * UNKNOWN represents a square that the player has neither marked nor stepped on
 */
extern const int UNKNOWN;

/*
 * MARKED represents a square that the player has marked
 */
extern const int MARKED;

/*
 * MINE represents a square that contains a mine
 */
extern const int MINE;


/*
 * map points to the first field of the Minesweeper board. The board is stored
 *   as a (flat) 1D-array with width * height elements. Squares are stored in
 *   the following order (column,row):
 * [0,0], [1,0], [2,0], ..., [width,0], [1,1], [2,1], ..., [width,height]
 */
extern int *board;
extern int *map;

/*
 * mine_at(c, r) returns true if there is a mine at ([c]olumn,[r]ow), and false
 *   otherwise. The function also returns false if ([c],[r]) is outside of the
 *   board.
 */
bool mine_at(const int c, const int r);

/*
 * all_marked(map) returns true if all squares with mines are marked and all
 *   marked squares contain mines, and false otherwise.
 */
bool all_marked(void);

/*
 * init_d(w, h, seed) creates a randomly generated board as well as an empty
 *   map, both with given [w]idth and [h]eight. All squares in map are
 *   initizlized to UNKNOWN. Using the same parameters [w], [h], and [seed]
 *   guarantees creation of the same board.
 */
int init_d(const char size, const char hardness);

/*
 * shutdown() removes the board and the map from memory.
 */
void shutdown();

#endif /* GAME_CORE_H */

