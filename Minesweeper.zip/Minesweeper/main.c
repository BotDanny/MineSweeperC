#include <assert.h>
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "game.h"

/*
 * Delete the // before the print_clear(width) function to see the transparent board
 */
int main(void) {
    bool state = true;
    while (state) {
        char input;
        int size = -1, hard = -1;
        printf("Please select the size of the game, s for small, m for medium and l for large\n");
        scanf(" %c", &size);
        printf("Please select the difficulty of the game, e for easy, m for medium and h for hard\n");
        scanf(" %c", &hard);
        int width = init_d(size, hard);
        print(width);
        //print_clear(width);
        user_guide();
        do {
            printf("Please enter a command then a position:\n");
            scanf(" %c", &input);
            if (input == 'S' || input == 's') {
                int c = -1, r = -1;
                scanf(" %d", &c);
                scanf(" %d", &r);
                bool mine = step(c, r, width);
                print(width);
                //print_clear(width);
                if (mine) {
                    printf("You stepped on a mine. Game over!\n");
                    print_clear(width);
                    printf("Want to play another game? Y for yes and N for no\n");
                    scanf(" %c", &input);
                    if (input == 'Y') {
                        state = true;
                    } else {
                        state = false;
                        printf("Thanks for playing. See you soon!\n");
                    }
                    input = EOF;
                    shutdown();
                }
            } else if (input == 'A' || input == 'a') {
                int c = -1, r = -1;
                scanf(" %d", &c);
                scanf(" %d", &r);
                bool mine = step_adv(c, r, width);
                print(width);
                //print_clear(width);
                if (mine) {
                    printf("You stepped on a mine. Game over!\n");
                    print_clear(width);
                    printf("Want to play another game? Y for yes and N for no\n");
                    scanf(" %c", &input);
                    if (input == 'Y') {
                        state = true;
                    } else {
                        state = false;
                        printf("Thanks for playing. See you soon!\n");
                    }
                    input = EOF;
                    shutdown();
                }
            } else if (input == 'M' || input == 'm') {
                int c = -1, r = -1;
                scanf(" %d", &c);
                scanf(" %d", &r);
                bool finished = mark(c, r, width);
                print(width);
                //print_clear(width);
                if (finished) {
                    printf("You marked all mines. Congratulations, well done!\n");
                    shutdown();
                    printf("Want to play another game? Y for yes and N for no\n");
                    scanf(" %c", &input);
                    if (input == 'Y') {
                        state = true;
                    } else {
                        state = false;
                        printf("Thanks for playing. See you soon!\n");
                    }
                    input = EOF;
                }
            } else if (input == 'P' || input == 'p') {
                print(width);
                //print_clear(width);
            } else if (input == 'U' || input == 'u') {
                user_guide();
            } else if (input == 'Q' || input == 'q') {
                printf("Thanks for playing. See you soon!\n");
                shutdown();
                input = EOF;
                state = false;
            }
        } while (input != EOF);
    }
}